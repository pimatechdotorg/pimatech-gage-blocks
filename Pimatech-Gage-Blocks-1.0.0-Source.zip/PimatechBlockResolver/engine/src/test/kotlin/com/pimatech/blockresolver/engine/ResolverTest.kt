package com.pimatech.blockresolver.engine
import java.math.BigDecimal
import org.junit.Assert.*
import org.junit.Test
import kotlin.random.Random
class ResolverTest {
 private val kit=Kit.INCH81
 private fun solve(v:String,vararg blocks:Int)=Resolver.solve(BigDecimal(v),kit,blocks.mapIndexed {i,b->Block(i+1,b)})
 @Test fun presetCompositions() {
  assertEquals(81,kit.standard().size);assertEquals(87,Kit.METRIC87.standard().size)
  assertEquals(2652950L,kit.standard().sumOf{it.ticks.toLong()})
  assertEquals(7152950L,Kit.METRIC87.standard().sumOf{it.ticks.toLong()})
  assertFalse(kit.standard().any{it.ticks==10005})
  assertEquals(81,kit.standard().map{it.id}.distinct().size)
 }
 @Test fun knownExactStacks() {
  val a=Resolver.solve(BigDecimal("2.4321"),kit,kit.standard())
  assertTrue(a.exact);assertEquals(243210L,a.totalTicks);assertEquals(4,a.blocks.size)
  val b=Resolver.solve(BigDecimal("2.5"),kit,kit.standard())
  assertTrue(b.exact);assertEquals(2,b.blocks.size)
  val c=Resolver.solve(BigDecimal("25.432"),Kit.METRIC87,Kit.METRIC87.standard())
  assertTrue(c.exact);assertEquals(254320L,c.totalTicks)
 }
 @Test fun duplicateCopiesAndUnavailable() {
  assertEquals(10000L,solve(".2",10000).totalTicks)
  assertEquals(20000L,solve(".2",10000,10000).totalTicks)
  val r=Resolver.solve(BigDecimal(".2"),kit,listOf(Block(1,10000),Block(2,10000,false)))
  assertEquals(10000L,r.totalTicks);assertEquals(listOf(1),r.blocks.map{it.id})
 }
 @Test fun minimumCountAndGreedyCounterexample() {
  val a=solve(".21",15000,11000,10000)
  assertTrue(a.exact);assertEquals(listOf(11000,10000),a.blocks.map{it.ticks})
  assertEquals(1,solve(".2",10000,10000,20000).blocks.size)
  assertEquals(6,solve(".6",10000,10000,10000,10000,10000,10000).blocks.size)
 }
 @Test fun nearestAndTies() {
  assertEquals(10000L,solve(".15",10000,20000).totalTicks)
  assertEquals(30000L,solve(".25",10000,10000,30000).totalTicks)
  val a=Resolver.solve(BigDecimal(".10005"),kit,kit.standard())
  assertFalse(a.exact);assertEquals(10000L,a.totalTicks)
  assertEquals(BigDecimal("-0.00005"),a.delta)
  assertEquals(40000L,solve("1000000000",10000,30000).totalTicks)
  assertEquals(0L,solve("0",10000).totalTicks)
  assertEquals(0L,solve(".01",10000).totalTicks)
 }
 @Test fun decimalPrecisionAndArbitraryGcd() {
  assertTrue(solve(".10005",10005).exact)
  assertEquals(7L,solve(".00008",7,21).totalTicks)
  assertTrue(solve(".00021",7,21).exact)
  assertFalse(solve(".10000001",10000).exact)
  assertEquals(BigDecimal("-0.00000001"),solve(".10000001",10000).delta)
 }
 @Test fun bruteForceOracle() {
  val random=Random(20261027)
  repeat(400) {case->
   val blocks=(0 until random.nextInt(1,13)).map{i->Block(i+1,random.nextInt(1,60),random.nextInt(5)!=0)}
   val targetTicks=BigDecimal(random.nextInt(0,450)).add(if(case%2==0) BigDecimal.ZERO else BigDecimal("0.5"))
   val wanted=targetTicks.movePointLeft(5)
   val a=Resolver.solve(wanted,kit,blocks)
   var bestSum=0L;var bestCount=0;var bestDiff=targetTicks
   for(mask in 0 until (1 shl blocks.size)) {
    var sum=0L;var count=0;var valid=true
    for(i in blocks.indices) if(mask and (1 shl i)!=0) {if(!blocks[i].available)valid=false;sum+=blocks[i].ticks;count++}
    if(valid) {
     val diff=BigDecimal.valueOf(sum).subtract(targetTicks).abs()
     if(diff<bestDiff || diff==bestDiff && (count<bestCount || count==bestCount && sum<bestSum)) {bestSum=sum;bestCount=count;bestDiff=diff}
    }
   }
   assertEquals("Nearest sum for $blocks / $wanted",bestSum,a.totalTicks)
   assertEquals(bestCount,a.blocks.size)
   assertEquals(a.blocks.size,a.blocks.map{it.id}.distinct().size)
   assertTrue(a.blocks.all{it.available && it in blocks})
   assertEquals(a.totalTicks,a.blocks.sumOf{it.ticks.toLong()})
  }
 }
 @Test fun invalidAndResourceGuards() {
  fun invalid(block:()->Unit) {try{block();fail("Expected rejection")}catch(_:IllegalArgumentException){}}
  invalid{solve("-1",100)};invalid{solve("1000000001",100)};invalid{solve("1",0)}
  invalid{Resolver.solve(BigDecimal.ONE,kit,listOf(Block(1,1),Block(1,2)))}
  invalid{solve("1",*(IntArray(129){1}))}
  invalid{solve("1000",Int.MAX_VALUE,1)}
  assertThrows(java.util.concurrent.CancellationException::class.java){Resolver.solve(BigDecimal.ONE,kit,kit.standard()){true}}
 }
 @Test fun emptyInventoryAndDeterminism() {
  val a=Resolver.solve(BigDecimal.ONE,kit,emptyList());assertEquals(0L,a.totalTicks);assertFalse(a.exact)
  val b=Resolver.solve(BigDecimal.ZERO,kit,emptyList());assertTrue(b.exact)
  assertEquals(solve(".2",10000,10000,20000),solve(".2",10000,10000,20000))
 }
}
