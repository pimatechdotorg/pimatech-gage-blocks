package com.pimatech.blockresolver.engine
import java.math.BigDecimal
import java.math.RoundingMode
import java.util.BitSet
import java.util.concurrent.CancellationException

data class Block(val id:Int,val ticks:Int,val available:Boolean=true)
enum class Kit(val title:String,val unit:String,val decimals:Int,val example:String) {
 INCH81("81-piece inch","in",5,"2.4321"), METRIC87("87-piece metric","mm",4,"25.432");
 fun value(ticks:Long):BigDecimal=BigDecimal.valueOf(ticks).movePointLeft(decimals)
 fun label(ticks:Long):String=value(ticks).setScale(decimals).toPlainString()+" "+unit
 fun ticks(value:BigDecimal):Int=value.movePointRight(decimals).intValueExact().also { require(it>0) {"Block must be greater than zero."} }
 fun standard():List<Block> {
  val values=if(this==INCH81) (10010..10090 step 10).toList()+(10100..14900 step 100).toList()+(5000..95000 step 5000).toList()+listOf(100000,200000,300000,400000)
   else (10010..10090 step 10).toList()+(10100..14900 step 100).toList()+(5000..95000 step 5000).toList()+(100000..1000000 step 100000).toList()
  return values.sorted().mapIndexed { i,v->Block(i+1,v) }
 }
}
data class Stack(val blocks:List<Block>,val totalTicks:Long,val delta:BigDecimal) { val exact:Boolean get()=delta.signum()==0 }
object Resolver {
 const val MAX_BLOCKS=128
 const val MAX_STATES=2000000
 private fun gcd(a:Int,b:Int):Int { var x=a;var y=b;while(y!=0){val r=x%y;x=y;y=r};return x }
 fun solve(target:BigDecimal,kit:Kit,inventory:List<Block>,cancelled:()->Boolean={false}):Stack {
  require(target.signum()>=0 && target<=BigDecimal("1000000000")) {"Use a dimension from zero through 1,000,000,000."}
  require(inventory.size<=MAX_BLOCKS && inventory.all{it.ticks>0} && inventory.map{it.id}.distinct().size==inventory.size) {"Invalid block inventory."}
  val blocks=inventory.filter{it.available}.sortedWith(compareByDescending<Block>{it.ticks}.thenBy{it.id})
  if(blocks.isEmpty()) return Stack(emptyList(),0,target.negate())
  val divisor=blocks.map{it.ticks}.reduce(::gcd)
  val total=blocks.sumOf{it.ticks.toLong()/divisor}
  val targetTicks=target.movePointRight(kit.decimals)
  val floor=targetTicks.divide(BigDecimal(divisor),0,RoundingMode.FLOOR).longValueExact()
  val ceil=targetTicks.divide(BigDecimal(divisor),0,RoundingMode.CEILING).longValueExact()
  // A nearest over-target subset is at most one largest block above the target.
  val cap=minOf(total,ceil+blocks.first().ticks/divisor)
  require(cap<=MAX_STATES) {"Inventory needs too many search states at this resolution. Remove extra blocks or use a coarser inventory. No result calculated."}
  val n=cap.toInt();val count=ByteArray(n+1){(-1).toByte()};count[0]=0
  val history=ArrayList<BitSet>(blocks.size);var reached=0
  for(b in blocks) {
   if(cancelled() || Thread.currentThread().isInterrupted) throw CancellationException()
   val step=b.ticks/divisor;val chosen=BitSet();val upper=minOf(n.toLong(),reached.toLong()+step).toInt()
   if(step<=upper) for(sum in upper downTo step) {
    if(sum and 16383==0 && cancelled()) throw CancellationException()
    val previous=count[sum-step].toInt() and 255
    if(previous<255 && previous+1<(count[sum].toInt() and 255)) {count[sum]=(previous+1).toByte();chosen.set(sum)}
   }
   history.add(chosen);reached=upper
  }
  var below=minOf(n.toLong(),floor).toInt()
  while(below>0 && count[below].toInt() and 255==255) below--
  var above=if(ceil>n) n+1 else ceil.toInt()
  while(above<=n && count[above].toInt() and 255==255) above++
  fun error(sum:Int)=BigDecimal.valueOf(sum.toLong()*divisor).subtract(targetTicks).abs()
  val best=when {
   above>n->below
   error(above)<error(below)->above
   error(above)>error(below)->below
   (count[above].toInt() and 255)<(count[below].toInt() and 255)->above
   else->below
  }
  var left=best;val selected=ArrayList<Block>()
  for(i in blocks.indices.reversed()) if(history[i][left]) {selected.add(blocks[i]);left-=blocks[i].ticks/divisor}
  check(left==0 && selected.sumOf{it.ticks.toLong()}==best.toLong()*divisor && selected.size==(count[best].toInt() and 255)) {"Stack reconstruction failed."}
  val ticks=best.toLong()*divisor
  return Stack(selected.sortedWith(compareByDescending<Block>{it.ticks}.thenBy{it.id}),ticks,kit.value(ticks).subtract(target))
 }
}
