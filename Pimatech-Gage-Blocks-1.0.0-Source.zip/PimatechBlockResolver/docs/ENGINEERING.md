# Solver model and guarantees

A row is one physical block with a unique app ID, positive nominal size and an availability flag. Duplicate sizes require duplicate physical rows. Only available rows participate, and each row can be used once. Block sizes use integer ticks (.00001 in or .0001 mm); requested dimensions are parsed directly as BigDecimal, without floating-point conversion or silent rounding.

Results minimize absolute nominal height error, then number of physical blocks, then height. Therefore an exact combination always beats any approximate combination, and among exact combinations the fewest blocks are selected. The empty stack is a valid zero-height candidate. Equal sum/count paths are deterministic after sorting by decreasing size and then ID. App IDs are not manufacturer serial numbers.

## Algorithm

A bounded 0/1 subset-sum dynamic program stores the minimum block count for every reachable sum. It processes each block once, traversing sums downward to prevent repeated use. Sizes are divided by their greatest common divisor to reduce state count. Each block retains an immutable bitset of the sums improved during its stage. Backtracking stage bitsets in reverse reconstructs a valid physical subset. Mutable one-dimensional parent pointers are avoided because later updates can invalidate older parent paths and accidentally repeat blocks.

Nearest-height search includes both the closest reachable sum below and above the target and compares their exact decimal errors. Any nearest over-target subset can lose any one block to reach at/below target; otherwise removing that block would create a nearer over-target subset. Thus a nearest sum need not exceed ceil(target/gcd) + largestBlock/gcd. Search is capped at the lesser of that bound and the entire inventory sum, preserving the optimal answer.

Resource bounds: 128 rows and 2,000,000 states. Oversized searches are rejected before allocating the DP/backtracking buffers, with an explicit no-result error. The resolver does not return a partially searched stack as optimal and has no five-block shortcut. Cancellation is checked during the search. The UI computes on a background dispatcher and hides a stale answer immediately when input or inventory changes.

## Presets

81-piece inch: 9 sizes .1001–.1009 by .0001; 49 sizes .101–.149 by .001; 19 sizes .05–.95 by .05; 1, 2, 3, 4 in. Total inventory height 26.5295 in. No .10005 block is silently included; add one only if physically owned.

87-piece metric: 9 sizes 1.001–1.009 by .001; 49 sizes 1.01–1.49 by .01; 19 sizes .5–9.5 by .5; 10 sizes 10–100 by 10 mm. Total 715.295 mm.

Manufacturer composition reference: Mitutoyo catalog, metric/inch rectangular block tables, https://www.mitutoyo.com/webfoo/wp-content/uploads/E_section.pdf . Presets represent common compositions, not a claim that all brands/sets contain those exact sizes. The customized inventory is authoritative for calculation.

Each preset saves an independent inventory and requested dimension. Selecting another set recalls it rather than converting the dimension. Numeric Cancel leaves the value unchanged; availability/add/edit/remove changes save immediately. Restore resets only the currently selected set and its example.

## Measurement limits

EXACT describes nominal arithmetic only, not the realized height of a wrung stack. Calibration corrections, wringing film, thermal expansion, wear, dirt and measurement uncertainty are not modeled. The signed difference is stack minus requested. An approximate stack is marked closest/not exact; the app does not infer an acceptable tolerance or show a calibrated PASS/FAIL result.
