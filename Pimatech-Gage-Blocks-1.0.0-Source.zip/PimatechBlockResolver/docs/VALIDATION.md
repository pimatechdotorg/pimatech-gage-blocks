# Validation — 1.0.0 development preview

2026-10-27. The final restored project was built and tested successfully. This is a debuggable development build, not a production or Google Play release.

## Completed

- Gradle :engine:test :app:assembleDebug :app:lintDebug :app:testDebugUnitTest: BUILD SUCCESSFUL.
- Nine engine test groups, zero failures/errors. Known inch/metric stacks, minimal count, duplicate physical quantities, unavailable rows, greedy counterexamples, zero/empty stacks, exact decimal differences, arbitrary GCD, deterministic ties, cancellation, input and memory limits. A seeded independent exhaustive-subset oracle checks 400 small inventories with integer and half-tick targets.
- Four Compose/Robolectric host-side UI tests, zero failures/errors: default exact stack and availability persistence after Activity recreation; nearest/not-exact status and separate preset recall; add/edit/remove of a finer physical block; compact 320×480dp controls and numeric Cancel. Screens rendered using native graphics at 411×731dp were visually reviewed, including the inventory popup. These are host-side UI tests, not physical-device certification.
- Android lint: zero errors, one dependency-version warning. Existing app-family dependency versions are pinned for consistency.
- APK signature verifies using v2. Package com.pimatech.blockresolver; version 1.0.0/code 1; min API 26, target API 35.
- Manifest permission inspection confirms no INTERNET permission. The only permission is the app-specific AndroidX signature permission for non-exported dynamic receivers.
- The delivered APK hash matches the verified build output. Private development signing key is retained separately and excluded from the source archive.

Evidence XML, lint output and signature/permission results are in test-results/. Rendered main and inventory screens are in ui-proof/.

## Limits

No physical Android-device installation or measured stack acceptance test has been performed by the developer. Check a known setup and inventory on the intended device before shop use. Exact means nominal arithmetic; no calibration/temperature/wringing/measurement-uncertainty compensation is implied.

APK SHA256: ae9d5f98d8378e78caf4564d560e78069676361e189f97df72eebc57fccd348c
Signing certificate SHA256: 585f322b588cdf0799eb48781fdc0332e43ef37a483942891d13231ec3ff2608
