# PimaTech Gage Block Stack Resolver 1.0.0

Android development preview, same dark/cyan style as Ball Drop and Sine Bar. MIT licensed. Android 8/API 26 or newer. Works offline without accounts, ads, analytics or Internet permission.

Start from the common 81-piece inch or 87-piece metric preset. Inventory allows marking blocks unavailable, adding physical duplicates, editing nominal sizes, and removing rows. Each physical row is used at most once. Each preset remembers its own dimension and inventory; changing sets recalls that setup rather than converting a dimension.

Enter a dimension to find the fewest blocks for an exact nominal stack. If no exact stack exists, the app marks the nearest result NOT EXACT and shows its signed difference (stack minus requested). Equal-error solutions prefer fewer blocks, then lower height. The zero/empty stack is eligible. No five-block search limit.

Requested values use up to eight decimal places. Custom block resolution: 0.00001 in or 0.0001 mm. Default preset resolution: .0001 in or .001 mm. The inventory limit is 128 rows; an explicit error replaces any result if more than two million search states would be required. Calculations use exact decimal/integer arithmetic, with no silent target rounding.

EXACT is nominal arithmetic, not a certification of a wrung stack. Calibration corrections, wringing film, temperature, wear and uncertainty are not compensated. Check your inventory and known setups on the intended device.

## Build

JDK 17, Android SDK/build tools 35, Gradle 8.9, AGP 8.7.3, Kotlin 2.0.21, Compose BOM 2024.12.01.

Set ANDROID_HOME or a local.properties sdk.dir, then:

```sh
./gradlew :engine:test :app:assembleDebug :app:lintDebug :app:testDebugUnitTest
```

For update compatibility use `-PpimatechDebugKeystore=/absolute/path/blockresolver-debug.keystore` from the separately retained PRIVATE development signing backup. Never publish the keystore. Without it a local debug key will differ. This debug APK is not production signed; production distribution needs a retained release key and non-debuggable build.

The engine includes nine test groups, including 400 seeded exhaustive subset comparisons. Host-side Compose/Robolectric tests check screen actions and produce rendered screenshots. See docs/VALIDATION.md for the verified build state.

Preset composition reference: Mitutoyo catalog https://www.mitutoyo.com/webfoo/wp-content/uploads/E_section.pdf . Match the preset to your physical set, as manufacturers and kits vary.

Proudly made and released open source by PimaTech.org
