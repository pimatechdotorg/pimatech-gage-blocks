package com.pimatech.blockresolver
import android.content.Context
import com.pimatech.blockresolver.engine.*
import org.json.JSONArray
import org.json.JSONObject
import java.math.BigDecimal
data class Setup(val kit:Kit=Kit.INCH81,val target:String=kit.example,val inventory:List<Block> = kit.standard())
class LocalStore(context:Context) {
 private val prefs=context.getSharedPreferences("blocks",Context.MODE_PRIVATE)
 fun current():Kit=runCatching {Kit.valueOf(prefs.getString("kit","INCH81")!!)}.getOrDefault(Kit.INCH81)
 fun load(kit:Kit=current()):Setup=runCatching {
  val array=prefs.getString(kit.name+"_inventory",null)?.let(::JSONArray)
  val blocks=if(array==null) kit.standard() else (0 until array.length()).map {i->val o=array.getJSONObject(i);Block(o.getInt("id"),o.getInt("ticks"),o.getBoolean("available"))}
  val target=prefs.getString(kit.name+"_target",kit.example)!!
  require(BigDecimal(target).signum()>=0 && BigDecimal(target)<=BigDecimal("1000000000"))
  require(blocks.size<=Resolver.MAX_BLOCKS && blocks.all{it.ticks>0} && blocks.map{it.id}.distinct().size==blocks.size)
  Setup(kit,target,blocks)
 }.getOrDefault(Setup(kit))
 fun save(s:Setup) {
  val array=JSONArray();s.inventory.forEach {b->array.put(JSONObject().put("id",b.id).put("ticks",b.ticks).put("available",b.available))}
  prefs.edit().putString("kit",s.kit.name).putString(s.kit.name+"_target",s.target).putString(s.kit.name+"_inventory",array.toString()).apply()
 }
}
