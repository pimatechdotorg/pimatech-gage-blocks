package com.pimatech.blockresolver
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.Alignment
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.pimatech.blockresolver.engine.*
import java.math.BigDecimal
import kotlinx.coroutines.*
class MainActivity:ComponentActivity() {
 override fun onCreate(savedInstanceState:Bundle?) {
  super.onCreate(savedInstanceState);val store=LocalStore(this)
  setContent { MaterialTheme(colorScheme=darkColorScheme(primary=Cyan,background=Ink,surface=Panel,onSurface=Color.White,onBackground=Color.White,secondary=Good,error=Bad)) {
   var state by remember {mutableStateOf(store.load())}
   Calculator(state,{state=it;store.save(it)},{state=store.load(it);store.save(state)})
  } }
 }
}
@Composable fun Calculator(s:Setup,change:(Setup)->Unit,switch:(Kit)->Unit) {
 var popup by remember {mutableStateOf<String?>(null)}
 var entry by remember {mutableStateOf<Entry?>(null)}
 // Input keys hide an old answer before a new background search starts.
 var answer by remember(s) {mutableStateOf<Stack?>(null)}
 var error by remember(s) {mutableStateOf<String?>(null)}
 var busy by remember(s) {mutableStateOf(true)}
 LaunchedEffect(s) {
  try {
   answer=withContext(Dispatchers.Default) {val ctx=currentCoroutineContext();Resolver.solve(BigDecimal(s.target),s.kit,s.inventory){!ctx.isActive}}
  } catch(e:CancellationException) {throw e} catch(e:IllegalArgumentException) {error=e.message} catch(e:Exception) {error="Unable to resolve this inventory. No stack calculated."}
  finally {busy=false}
 }
 val kit=s.kit;val stack=answer;val color=if(stack?.exact==true) Good else Warn
 fun blockEntry() {
  entry=Entry("Add one physical block","",kit.unit,validate={v->runCatching {kit.ticks(v)}.exceptionOrNull()?.let{"Use a positive block size with at most ${kit.decimals} decimals and within the supported range."}}) {v->
   if(s.inventory.size<Resolver.MAX_BLOCKS) change(s.copy(inventory=s.inventory+Block((s.inventory.maxOfOrNull{it.id} ?: 0)+1,kit.ticks(v))))
  }
 }
 Surface(color=Ink,modifier=Modifier.fillMaxSize()) {
  BoxWithConstraints(Modifier.fillMaxSize().windowInsetsPadding(WindowInsets.safeDrawing)) {
   val fallback=maxHeight<640.dp || androidx.compose.ui.platform.LocalDensity.current.fontScale>1.3f
   Column(Modifier.fillMaxSize().then(if(fallback) Modifier.verticalScroll(rememberScrollState()) else Modifier).padding(horizontal=12.dp,vertical=6.dp),verticalArrangement=Arrangement.spacedBy(6.dp)) {
    Row(Modifier.fillMaxWidth(),verticalAlignment=Alignment.CenterVertically) {
     Column(Modifier.weight(1f)) {Text("PIMATECH",color=Cyan,fontSize=12.sp,fontWeight=FontWeight.Bold,letterSpacing=2.sp);Text("GAGE BLOCKS",fontSize=20.sp,fontWeight=FontWeight.Bold)}
     TextButton(onClick={popup="sets"}) {Text(kit.unit.uppercase(),fontWeight=FontWeight.Bold)}
    }
    ValueButton("Requested dimension · ${kit.unit}",s.target+" "+kit.unit,Modifier.fillMaxWidth()) {
     entry=Entry("Requested dimension",s.target,kit.unit,validate={if(it.signum()>=0 && it<=BigDecimal("1000000000") && it.scale()<=8) null else "Use zero through 1,000,000,000 with at most 8 decimal places."}) {change(s.copy(target=it.stripTrailingZeros().toPlainString()))}
    }
    ValueButton("Active inventory · tap to customize",kit.title+" · ${s.inventory.count{it.available}} available",Modifier.fillMaxWidth()) {popup="inventory"}
    Surface(color=Panel,shape=RoundedCornerShape(12.dp),modifier=Modifier.fillMaxWidth().then(if(fallback) Modifier.height(235.dp) else Modifier.weight(1f)).clickable{popup="stack"}) {
     Column(Modifier.padding(12.dp),verticalArrangement=Arrangement.spacedBy(4.dp)) {
      Text("BLOCKS TO WRING  ·  TAP FOR FULL LIST",color=Muted,fontSize=10.sp)
      when {
       busy-> {LinearProgressIndicator(Modifier.fillMaxWidth());Text("Resolving available blocks…",color=Muted)}
       error!=null->Text(error!!,color=Bad,fontSize=14.sp)
       stack!=null-> {
        if(stack.blocks.isEmpty()) Text(if(stack.exact) "Zero dimension · no blocks required" else "No blocks in closest stack",color=Muted)
        LazyColumn(Modifier.weight(1f),verticalArrangement=Arrangement.spacedBy(5.dp)) {
         items(stack.blocks,key={it.id}) {b->BlockRow(b,kit)}
        }
       }
      }
     }
    }
    Surface(color=color.copy(alpha=.09f),shape=RoundedCornerShape(10.dp),modifier=Modifier.fillMaxWidth()) {
     Column(Modifier.padding(horizontal=12.dp,vertical=9.dp)) {
      Text(when {busy->"CALCULATING";error!=null->"NO RESULT";stack?.exact==true->"EXACT NOMINAL STACK";else->"CLOSEST STACK · NOT EXACT"},color=if(error!=null) Bad else color,fontSize=12.sp,fontWeight=FontWeight.Bold)
      Text(stack?.let{kit.label(it.totalTicks)} ?: "—",color=if(error!=null) Bad else color,fontSize=28.sp,fontWeight=FontWeight.Bold)
      Text(stack?.let{"${it.blocks.size} ${if(it.blocks.size==1) "block" else "blocks"}  ·  Δ stack − requested: "+(if(it.delta.signum()>0) "+" else "")+it.delta.stripTrailingZeros().toPlainString()+" "+kit.unit} ?: "No stack shown until the search completes.",color=Muted,fontSize=12.sp)
     }
    }
    Text(if(stack?.exact==true) "Fewest blocks for this exact nominal height." else if(stack!=null) "No exact stack available. Closest height shown; verify whether the difference is acceptable." else "Uses each available physical block at most once.",color=Muted,fontSize=11.sp,lineHeight=14.sp)
    InputRow {
     ActionButton("Inventory",Modifier.weight(1f)){popup="inventory"}
     ActionButton("Set / units",Modifier.weight(1f)){popup="sets"}
     ActionButton("Help",Modifier.weight(1f)){popup="help"}
     ActionButton("Reset",Modifier.weight(1f)){popup="reset"}
    }
    Attribution()
   }
  }
 }
 when(popup) {
  "stack"->ShopDialog("Resolved stack",{popup=null}) {
   Text("Requested: ${s.target} ${kit.unit}")
   if(busy) Text("Calculating…") else if(error!=null) Text(error!!,color=Bad) else stack?.let {a->
    Text(if(a.exact) "Exact nominal stack · fewest blocks" else "Closest nominal stack · not exact",color=if(a.exact) Good else Warn)
    a.blocks.forEach {BlockRow(it,kit)}
    Text("Total: ${kit.label(a.totalTicks)}\nDifference (stack − requested): ${a.delta.stripTrailingZeros().toPlainString()} ${kit.unit}")
    Text("Each row is one physical block. ID numbers distinguish duplicates; they are app inventory IDs, not manufacturer serial numbers. Row order is a convenient size order, not a required wringing sequence.",color=Muted,fontSize=12.sp)
   }
  }
  "inventory"-> {
   androidx.compose.ui.window.Dialog(onDismissRequest={popup=null}) {
    Surface(color=Panel,shape=RoundedCornerShape(16.dp)) {
     Column(Modifier.fillMaxWidth().heightIn(max=680.dp).padding(16.dp),verticalArrangement=Arrangement.spacedBy(6.dp)) {
      Text("My blocks · ${kit.unit}",color=Cyan,fontSize=21.sp,fontWeight=FontWeight.Bold)
      Text("Checked = available. Each row is one physical block. Uncheck missing or damaged blocks; add duplicates only when you own another block.",color=Muted,fontSize=12.sp)
      Text("${s.inventory.count{it.available}} available / ${s.inventory.size} listed · ${kit.title}",fontSize=12.sp)
      LazyColumn(Modifier.weight(1f,fill=false).heightIn(max=400.dp)) {
       items(s.inventory.sortedWith(compareBy<Block>{it.ticks}.thenBy{it.id}),key={it.id}) {b->
        Row(Modifier.fillMaxWidth().heightIn(min=48.dp).clickable{change(s.copy(inventory=s.inventory.map{if(it.id==b.id) it.copy(available=!it.available) else it}))},verticalAlignment=Alignment.CenterVertically) {
         Checkbox(checked=b.available,onCheckedChange={checked->change(s.copy(inventory=s.inventory.map{if(it.id==b.id) it.copy(available=checked) else it}))})
         Column(Modifier.weight(1f)) {Text(kit.label(b.ticks.toLong()),fontWeight=FontWeight.SemiBold);Text("Block #${b.id}",fontSize=10.sp,color=Muted)}
         TextButton(onClick={entry=Entry("Edit block #${b.id}",kit.value(b.ticks.toLong()).toPlainString(),kit.unit,validate={v->runCatching{kit.ticks(v)}.exceptionOrNull()?.let{"Use a positive size with at most ${kit.decimals} decimals."}},remove={change(s.copy(inventory=s.inventory.filter{it.id!=b.id}))}) {v->change(s.copy(inventory=s.inventory.map{if(it.id==b.id) it.copy(ticks=kit.ticks(v)) else it}))}}){Text("Edit")}
        }
       }
      }
      Button(onClick={blockEntry()},enabled=s.inventory.size<Resolver.MAX_BLOCKS,modifier=Modifier.fillMaxWidth()){Text("Add one block")}
      if(s.inventory.size>=Resolver.MAX_BLOCKS) Text("Maximum 128 rows. Remove an unused row through Edit to add another block.",color=Warn,fontSize=12.sp)
      TextButton(onClick={popup=null},modifier=Modifier.align(Alignment.End)){Text("Close")}
      Attribution()
     }
    }
   }
  }
  "sets"->ShopDialog("Set & units",{popup=null}) {
   Text("Choose a starting set. Each set keeps its own requested dimension and customized inventory on this device.")
   Kit.entries.forEach {k->OutlinedButton(onClick={switch(k)},modifier=Modifier.fillMaxWidth()){Text((if(k==kit) "✓ " else "")+k.title)}}
   Text("Dimensions and block labels use the selected set's native units. Switching sets does not convert a dimension; it recalls that set's saved setup.",color=Muted,fontSize=12.sp)
   Text("81-piece inch: .1001–.1009 by .0001; .101–.149 by .001; .05–.95 by .05; 1, 2, 3, 4 in.\n87-piece metric: 1.001–1.009 by .001; 1.01–1.49 by .01; .5–9.5 by .5; 10–100 by 10 mm.",fontSize=12.sp)
   Text("Check the inventory against your actual set. Presets describe common compositions; brands and sets vary. Add wear blocks or extra sizes only if physically present.",color=Muted,fontSize=12.sp)
  }
  "help"->ShopDialog("Operator & solver",{popup=null}) {
   Text("Enter a dimension. The resolver searches the checked inventory for the closest nominal height, preferring the fewest blocks when heights are equally close. If block counts also tie, it chooses the lower height. An exact match always wins over an approximate match.")
   Text("A physical block is used at most once. Extra copies must be separate inventory rows. There is no five-block search cap; the resolver may use any number of available blocks, up to the 128-row inventory limit.")
   Text("The inch preset resolves .0001 in increments; the metric preset resolves .001 mm increments. Add suitable finer blocks to extend resolution. Custom block sizes support 5 decimal places in inches or 4 in mm. Requested dimensions support 8 decimal places; they are not silently rounded to a block increment.")
   Text("EXACT means the nominal sizes add up exactly. It does not certify the realized stack. Block calibration corrections, wringing film, temperature, wear, and setup uncertainty are not modeled. Use clean, calibrated blocks and verify the assembled stack.")
   Text("The main list scrolls if needed; tap it for the full breakdown. Edit a row to change its nominal size or remove it. Inventory edits save immediately. Numeric Cancel discards that entry. Works offline with no accounts, ads or internet permission.")
   Text("Version 1.0.0 · Native Android · MIT open source",color=Muted,fontSize=12.sp)
  }
  "reset"->ShopDialog("Restore this standard set?",{popup=null}) {
   Text("Restore ${kit.title}, mark all standard blocks available, remove custom rows for this set, and restore the example dimension. The other set's saved setup stays available.")
   Button(onClick={change(Setup(kit));popup=null},modifier=Modifier.fillMaxWidth()){Text("Restore standard set")}
  }
 }
 entry?.let {e->NumericDialog(e,{entry=null}){e.commit(it);entry=null}}
}
@Composable fun BlockRow(b:Block,kit:Kit) {
 Surface(color=Cyan.copy(alpha=.09f),shape=RoundedCornerShape(7.dp),modifier=Modifier.fillMaxWidth()) {
  Row(Modifier.padding(horizontal=12.dp,vertical=6.dp),verticalAlignment=Alignment.CenterVertically) {
   Text(kit.label(b.ticks.toLong()),fontSize=20.sp,fontWeight=FontWeight.SemiBold,color=Cyan,modifier=Modifier.weight(1f))
   Text("#${b.id}",fontSize=11.sp,color=Muted)
  }
 }
}
