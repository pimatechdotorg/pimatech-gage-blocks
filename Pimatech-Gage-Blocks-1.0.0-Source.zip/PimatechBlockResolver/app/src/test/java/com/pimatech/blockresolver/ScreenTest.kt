package com.pimatech.blockresolver
import android.graphics.Bitmap
import android.graphics.Canvas
import androidx.compose.ui.test.*
import androidx.compose.ui.test.junit4.createAndroidComposeRule
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import org.robolectric.annotation.GraphicsMode
import java.io.File
@RunWith(RobolectricTestRunner::class)
@Config(sdk=[28],qualifiers="w411dp-h731dp-port")
@GraphicsMode(GraphicsMode.Mode.NATIVE)
class ScreenTest {
 @get:Rule val rule=createAndroidComposeRule<MainActivity>()
 private fun ready(text:String) {rule.waitUntil(20000){rule.onAllNodesWithText(text).fetchSemanticsNodes().isNotEmpty()}}
 private fun shot(name:String,dialog:Boolean=false) {rule.runOnIdle {
  val view=if(dialog) org.robolectric.shadows.ShadowDialog.getLatestDialog().window!!.decorView else rule.activity.window.decorView
  val bitmap=Bitmap.createBitmap(view.width,view.height,Bitmap.Config.ARGB_8888)
  view.draw(Canvas(bitmap));val file=File("build/ui-proof/"+name+".png");file.parentFile.mkdirs();file.outputStream().use{bitmap.compress(Bitmap.CompressFormat.PNG,100,it)}
 }}
 @Test fun defaultScreenAndInventory() {
  ready("EXACT NOMINAL STACK")
  rule.onNodeWithText("2.43210 in").assertIsDisplayed()
  rule.onNodeWithText("Proudly made and released open source by PimaTech.org").assertIsDisplayed()
  shot("default")
  rule.onNodeWithText("Inventory").performClick()
  rule.onNodeWithText("My blocks · in").assertIsDisplayed()
  rule.onNodeWithText("0.05000 in").performClick()
  rule.onNodeWithText("80 available / 81 listed · 81-piece inch").assertIsDisplayed()
  shot("inventory",dialog=true)
  rule.onNodeWithText("Close").performClick()
  rule.activityRule.scenario.recreate()
  ready("EXACT NOMINAL STACK")
  rule.onNodeWithText("81-piece inch · 80 available").assertIsDisplayed()
 }
 @Test fun unrepresentableDimensionAndSetRecall() {
  ready("EXACT NOMINAL STACK")
  rule.onNodeWithText("Requested dimension · in").performClick()
  listOf("0",".","1","0","0","0","5").forEach {rule.onNodeWithText(it).performClick()}
  rule.onNodeWithText("Save").performClick()
  ready("CLOSEST STACK · NOT EXACT")
  rule.onAllNodesWithText("0.10000 in")[0].assertIsDisplayed()
  rule.onNodeWithText("1 block  ·  Δ stack − requested: -0.00005 in").assertIsDisplayed()
  shot("closest")
  rule.onNodeWithText("Set / units").performClick()
  rule.onNodeWithText("87-piece metric").performClick()
  rule.onNodeWithText("Close").performClick()
  ready("EXACT NOMINAL STACK")
  rule.onNodeWithText("25.4320 mm").assertIsDisplayed()
  rule.onNodeWithText("Set / units").performClick()
  rule.onNodeWithText("81-piece inch").performClick()
  rule.onNodeWithText("Close").performClick()
  ready("CLOSEST STACK · NOT EXACT")
  rule.onNodeWithText("0.10005 in").assertIsDisplayed()
 }
 @Test @Config(qualifiers="w320dp-h480dp-port")
 fun compactViewportCanReachControls() {
  ready("EXACT NOMINAL STACK")
  rule.onNodeWithText("Proudly made and released open source by PimaTech.org").performScrollTo().assertIsDisplayed()
  rule.onNodeWithText("Requested dimension · in").performScrollTo().performClick()
  rule.onNodeWithText("Requested dimension").assertIsDisplayed()
  rule.onNodeWithText("Cancel").performScrollTo().performClick()
  rule.onNodeWithText("Requested dimension · in").assertIsDisplayed()
 }
 @Test fun addEditAndRemoveFinerBlock() {
  ready("EXACT NOMINAL STACK")
  rule.onNodeWithText("Requested dimension · in").performClick()
  listOf("0",".","1","0","0","0","5").forEach {rule.onNodeWithText(it).performClick()}
  rule.onNodeWithText("Save").performClick()
  ready("CLOSEST STACK · NOT EXACT")
  rule.onNodeWithText("Inventory").performClick()
  rule.onNodeWithText("Add one block").performClick()
  listOf("0",".","1","0","0","0","5").forEach {rule.onNodeWithText(it).performClick()}
  rule.onNodeWithText("Save").performClick()
  rule.onNodeWithText("82 available / 82 listed · 81-piece inch").assertIsDisplayed()
  rule.onNodeWithText("Close").performClick()
  ready("EXACT NOMINAL STACK")
  rule.onNodeWithText("Inventory").performClick()
  rule.onNode(hasText("Edit") and hasAnyAncestor(hasText("Block #82"))).performClick()
  listOf("0",".","1","0","0","0","6").forEach {rule.onNodeWithText(it).performClick()}
  rule.onNodeWithText("Save").performClick()
  rule.onNodeWithText("0.10006 in").assertIsDisplayed()
  rule.onNodeWithText("Close").performClick()
  ready("CLOSEST STACK · NOT EXACT")
  rule.onNodeWithText("1 block  ·  Δ stack − requested: +0.00001 in").assertIsDisplayed()
  rule.onNodeWithText("Inventory").performClick()
  rule.onNode(hasText("Edit") and hasAnyAncestor(hasText("Block #82"))).performClick()
  rule.onNodeWithText("Remove this physical block").performClick()
  rule.onNodeWithText("81 available / 81 listed · 81-piece inch").assertIsDisplayed()
  rule.onNodeWithText("Close").performClick()
  ready("CLOSEST STACK · NOT EXACT")
  rule.onNodeWithText("1 block  ·  Δ stack − requested: -0.00005 in").assertIsDisplayed()
 }

}
